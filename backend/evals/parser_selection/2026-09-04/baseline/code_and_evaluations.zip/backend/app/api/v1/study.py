"""Authenticated Study API mounted at /api/v1/study."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from core.exceptions import NotFoundException, ValidationException
from database.session import get_db
from models.study import StudyDocument, StudyDocumentUnit
from models.user import User
from schemas.response import APIResponse
from schemas.study import (
    StudyDocumentListResponse,
    StudyDocumentResponse,
    StudyDocumentUnitListResponse,
    StudyDocumentUnitResponse,
    StudyParseResponse,
)
from services.study_files import LocalStudyStorage
from services.study_parser import StudyParseError, parse_and_store_document
from utils.auth import get_current_user_id


router = APIRouter(prefix="/study", tags=["study"])


@router.post(
    "/documents",
    response_model=APIResponse[StudyDocumentResponse],
    status_code=201,
)
async def upload_study_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id),
):
    """Validate and privately store one PDF or PPTX for the current user."""
    if db.get(User, current_user_id) is None:
        raise HTTPException(status_code=401, detail="登录用户不存在")

    document_id = str(uuid.uuid4())
    storage = LocalStudyStorage()
    stored = await storage.store_upload(
        upload=file,
        user_id=current_user_id,
        document_id=document_id,
    )

    document = StudyDocument(
        id=document_id,
        user_id=current_user_id,
        original_filename=stored.original_filename,
        file_type=stored.file_type,
        storage_path=stored.storage_path,
        file_size=stored.size,
        sha256=stored.sha256,
        status="uploaded",
    )
    try:
        db.add(document)
        db.commit()
        db.refresh(document)
    except Exception:
        db.rollback()
        storage.delete(stored.storage_path)
        raise

    return APIResponse.ok(
        data=StudyDocumentResponse.model_validate(document),
        message="学习资料上传成功",
    )


@router.post(
    "/documents/{document_id}/parse",
    response_model=APIResponse[StudyParseResponse],
)
def parse_study_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id),
):
    """Parse one owned source file into page- or slide-level units."""
    document = (
        db.query(StudyDocument)
        .filter(
            StudyDocument.id == document_id,
            StudyDocument.user_id == current_user_id,
        )
        .first()
    )
    if document is None:
        raise NotFoundException("学习资料不存在")
    try:
        unit_count = parse_and_store_document(db, document)
    except StudyParseError as exc:
        raise ValidationException(exc.message) from exc
    db.refresh(document)
    return APIResponse.ok(data=StudyParseResponse(
        document=StudyDocumentResponse.model_validate(document),
        unit_count=unit_count,
    ))


@router.get(
    "/documents/{document_id}/units",
    response_model=APIResponse[StudyDocumentUnitListResponse],
)
def list_study_document_units(
    document_id: str,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id),
):
    """List parsed units only when the source document belongs to the user."""
    document = (
        db.query(StudyDocument.id)
        .filter(
            StudyDocument.id == document_id,
            StudyDocument.user_id == current_user_id,
        )
        .first()
    )
    if document is None:
        raise NotFoundException("学习资料不存在")
    units = (
        db.query(StudyDocumentUnit)
        .filter(StudyDocumentUnit.document_id == document_id)
        .order_by(StudyDocumentUnit.page_number, StudyDocumentUnit.unit_index)
        .all()
    )
    return APIResponse.ok(data=StudyDocumentUnitListResponse(
        total=len(units),
        units=[StudyDocumentUnitResponse.model_validate(unit) for unit in units],
    ))


@router.get(
    "/documents",
    response_model=APIResponse[StudyDocumentListResponse],
)
def list_study_documents(
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id),
):
    """List only the authenticated user's learning documents."""
    documents = (
        db.query(StudyDocument)
        .filter(StudyDocument.user_id == current_user_id)
        .order_by(StudyDocument.created_at.desc())
        .all()
    )
    return APIResponse.ok(
        data=StudyDocumentListResponse(
            total=len(documents),
            documents=[StudyDocumentResponse.model_validate(item) for item in documents],
        )
    )


@router.get(
    "/documents/{document_id}",
    response_model=APIResponse[StudyDocumentResponse],
)
def get_study_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user_id: str = Depends(get_current_user_id),
):
    """Return a document only when it belongs to the authenticated user."""
    document = (
        db.query(StudyDocument)
        .filter(
            StudyDocument.id == document_id,
            StudyDocument.user_id == current_user_id,
        )
        .first()
    )
    if document is None:
        raise NotFoundException("学习资料不存在")
    return APIResponse.ok(data=StudyDocumentResponse.model_validate(document))
