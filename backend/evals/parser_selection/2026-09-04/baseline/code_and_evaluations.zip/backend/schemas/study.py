"""Pydantic response schemas for the Study API."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict


class StudyDocumentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    original_filename: str
    file_type: str
    file_size: int
    status: str
    page_count: int | None
    error_code: str | None
    error_message: str | None
    created_at: datetime
    updated_at: datetime


class StudyDocumentListResponse(BaseModel):
    total: int
    documents: list[StudyDocumentResponse]


class StudyDocumentUnitResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    page_number: int
    unit_index: int
    unit_type: str
    raw_text: str
    normalized_text: str
    safe_text: str
    extraction_method: str
    ocr_confidence: float | None
    ocr_blocks: list[dict]
    quality_status: str
    quality_reasons: list[str]


class StudyDocumentUnitListResponse(BaseModel):
    total: int
    units: list[StudyDocumentUnitResponse]


class StudyParseResponse(BaseModel):
    document: StudyDocumentResponse
    unit_count: int


__all__ = [
    "StudyDocumentResponse",
    "StudyDocumentListResponse",
    "StudyDocumentUnitResponse",
    "StudyDocumentUnitListResponse",
    "StudyParseResponse",
]
